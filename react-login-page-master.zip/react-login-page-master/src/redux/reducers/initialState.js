export default {
  users: [],
  posts: [],
  user: {},
  apiCallsInProgress: 0
};
